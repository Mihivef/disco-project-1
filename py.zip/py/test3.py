import numpy as np
from copy import deepcopy

def find_min_zero_row(zeromatrix, zeromarked):
    minrow = [float('inf'), -1]
    for numrow in range(zeromatrix.shape[0]):
        countzeroes = np.sum(zeromatrix[numrow] == 0)
        if countzeroes > 0 and minrow[0] > countzeroes:
            minrow = [countzeroes, numrow]
    indexzero = np.where(zeromatrix[minrow[1]] == 0)[0][0]
    zeromarked.append((minrow[1], indexzero))
    zeromatrix[minrow[1], :] = float('inf')
    zeromatrix[:, indexzero] = float('inf')

def markedmatrix(matrix):
    culmatrix = matrix
    zeroboolmat = (culmatrix == 0)
    zeroboolmatcopy = zeroboolmat.copy()
    zeromarked = []
    while True in zeroboolmatcopy:
        find_min_zero_row(zeroboolmatcopy, zeromarked)
    zeromarkedrow = [pos[0] for pos in zeromarked]
    zeromarkedcol = [pos[1] for pos in zeromarked]
    rownonmarked = list(set(range(culmatrix.shape[0])) - set(zeromarkedrow))
    columnmarked = []
    checkit = True

    while checkit:
        checkit = False
        for i in range(len(rownonmarked)):
            row_array = zeroboolmat[rownonmarked[i], :]
            for j in range(row_array.shape[0]):
                if row_array[j] == True and j not in columnmarked:
                    columnmarked.append(j)
                    checkit = True
        for numrow, col_num in zeromarked:
            if numrow not in rownonmarked and col_num in columnmarked:
                rownonmarked.append(numrow)
                checkit = True
    marked_rows = list(set(range(matrix.shape[0])) - set(rownonmarked))
    return zeromarked, marked_rows, columnmarked

def adjmatrix(matrix, cover_rows, cover_cols):
    culmatrix = matrix
    numberofnonzeroelements = []

    for row in range(len(culmatrix)):
        if row not in cover_rows:
            for i in range(len(culmatrix[row])):
                if i not in cover_cols:
                    if culmatrix[row, i] != float('inf'):
                        numberofnonzeroelements.append(culmatrix[row, i])
    min_num = min(numberofnonzeroelements)

    for row in range(len(culmatrix)):
        if row not in cover_rows:
          for i in range(len(culmatrix[row])):
            if i not in cover_cols:
             if culmatrix[row, i] != float('inf'):
               culmatrix[row, i] = culmatrix[row, i] - min_num

    for row in range(len(cover_rows)):
        for col in range(len(cover_cols)):
            culmatrix[cover_rows[row], cover_cols[col]] = culmatrix[cover_rows[row], cover_cols[col]] + min_num
    return culmatrix

def hungalgo(matrix):
    dim = matrix.shape[0]
    culmatrix = matrix
    for numrow in range(matrix.shape[0]):
        min_val = np.min(culmatrix[numrow])
        if min_val > 0:
            culmatrix[numrow] = culmatrix[numrow] - min_val
    for col_num in range(matrix.shape[1]):
        min_val = np.min(culmatrix[:, col_num])
        if min_val > 0:
            culmatrix[:, col_num] = culmatrix[:, col_num] - min_val
    zero_count = 0
    while zero_count < dim:
        ans_pos, marked_rows, columnmarked = markedmatrix(culmatrix)
        zero_count = len(marked_rows) + len(columnmarked)
        if zero_count < dim:
            culmatrix = adjmatrix(culmatrix, marked_rows, columnmarked)
    return ans_pos

def calculate_answer(matrix, pos):
    total = 0
    ans_matrix = np.zeros((matrix.shape[0], matrix.shape[1]))
    for i in range(len(pos)):
        total += matrix[pos[i][0], pos[i][1]]
        ans_matrix[pos[i][0], pos[i][1]] = matrix[pos[i][0], pos[i][1]]
    return total, ans_matrix

def solve(matrix):
    cost_matrix = matrix
    ans_pos = hungalgo(cost_matrix.copy())
    ans, ans_matrix = calculate_answer(cost_matrix, ans_pos)
    return [int(ans), ans_matrix]

# Main Code
professor_dictionary = {}
professors = {}
error = 'Not Possible'
n = 0
crsdic1 = {}
crsdic2 = {}

with open("input.txt") as datain:
    listofcrs = datain.readline().split()
    print('LIST OF COURSES OFFERED :\n', listofcrs)
    L = len(listofcrs)
    cnt = 0
    for i in range(L):
        crsdic1[i] = listofcrs[i // 2]
        crsdic2[listofcrs[i // 2]] = [i - i % 2, i - i % 2 + 1]
    hungmat = np.zeros(shape=(L, L))
    cnt = 0
    while True:
        proffinfo = datain.readline().split()
        if proffinfo:
            count = 0
            for i in proffinfo:
                if (count >= 2):
                   hungmat[cnt][listofcrs.index(i)] = 1
                count = count + 1
            cnt += 1 
            name, prof_type = proffinfo[0], float(proffinfo[1])
            professors[name] = [prof_type, set()]
            x = int(prof_type // 0.5)
            for i in range(x):
                professor_dictionary[n + i] = name
            courses_professor = proffinfo[2:]
            for i in range(len(courses_professor)):
                if crsdic2[courses_professor[i]][0] != float('inf'):
                    hungmat[crsdic2[courses_professor[i]][0]][n : n + x] = i + 1
                if crsdic2[courses_professor[i]][1] != float('inf'):
                    hungmat[crsdic2[courses_professor[i]][1]][n : n + x] = i + 1
            n += x
        else:
            break
print(hungmat)   
for i in range(0,len(professor_dictionary)):
    c =0
    for col in np.nditer(hungmat.T):
        c=c+1
        if col==1:
            print(str(i) + "faculty is assigned course id" + str(c))
        

if n != L:
    print(error)
else:
    min_cost, solution_1 = solve(hungmat)

    if min_cost >= float('inf'):
        print('\n\n', error)
    else:
        print('\n\nBEST OPTIMAL ASSIGNMENT :')
        answerset = set()
        def solve_solution(sln):
            ans = deepcopy(professors)

            for i in range(n):
                for j in range(n):
                    if sln[i][j]:
                        course = crsdic1[i]
                        ans[professor_dictionary[j]][1].add(course)

            answerset.add(str(ans))

        solve_solution(solution_1)

        for i in range(n):
            for j in range(n):
                org = hungmat[i][j]
                hungmat[i][j] = float('inf')
                m, sln = solve(hungmat)

                if m == min_cost:
                    solve_solution(sln)

                hungmat[i][j] = org

        for ans in answerset:
            print(ans)